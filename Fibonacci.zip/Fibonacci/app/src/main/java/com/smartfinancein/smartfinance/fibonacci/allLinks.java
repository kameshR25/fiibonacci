package com.smartfinancein.smartfinance.fibonacci;

/**
 * Created by SmartFinance on 01-03-2017.
 */
public class allLinks {


    //Join WhatsApp link
    public  static String joinWhatsAppLink="https://smartfinancein.com/workweb/whatsAppLink.php";
    //Find Whats App status link
    public  static String userWhatsAppStatus="https://smartfinancein.com/workweb/findWhatsAppStatus.php?ssid={0}";
    //Update Whats App status link
    public  static String updateWhatsAppStatus="https://smartfinancein.com/workweb/updateWhatsAppStatus.php?ssid={0}&status={1}";
    //Latest option strategy from youtube channel
    public static String latestStrategy="https://smartfinancein.com/workweb/newStrategy.php";
    //Registration Link
    public  static String registerLink="https://www.smartfinancein.com/workweb/freeAppUser.php?userid={0}&password={1}&name={2}&email={3}&phone={4}&ssid={5}&logDate={6}&expiry={7}&logstatus={8}&appName={9}";
    //How to use link
    public static String howToUseLink="https://www.smartfinancein.com/workweb/howToUseFibonacciCalculator.php";
    //Find User Agreement status link
    public  static String userAgreementStatusUrl="https://smartfinancein.com/workweb/findUserAgreementStatus.php?ssid={0}";
    //User Agreement
    public  static String userAgreementUrl="https://smartfinancein.com/workweb/updateUserAgreementStatus.php?ssid={0}&status={1}";
}
